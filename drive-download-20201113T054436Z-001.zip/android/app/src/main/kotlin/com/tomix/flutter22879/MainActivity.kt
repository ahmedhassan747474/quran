package com.tomix.flutter22879

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
